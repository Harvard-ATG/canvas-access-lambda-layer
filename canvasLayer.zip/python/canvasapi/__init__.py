# -*- coding: utf-8 -*-

from canvasapi.canvas import Canvas

__all__ = ["Canvas"]

__version__ = "3.2.0"
